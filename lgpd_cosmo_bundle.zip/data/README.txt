
This folder is intentionally empty. Please place public datasets here if you want to run against real observations:

- Planck baseline Cls:
  `planck_baseline_cls.npz` with arrays: ell, cltt, clte, clee, (optional) clbb, clpp

- Simple binned TT/TE/EE (CSV with header):
  ell, Dl, sigma

- BAO (CSV):
  z, DV_over_rd, sigma

- SNe (CSV):
  z, mu, sigma

- Growth (CSV):
  z, fsigma8, sigma
